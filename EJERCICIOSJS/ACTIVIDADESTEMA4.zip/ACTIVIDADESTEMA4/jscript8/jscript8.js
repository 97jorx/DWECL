

function palabras() {
    var valores = [true, 5, false, "hola", "adios", 2]
    document.getElementById("o1").value= valores.sort(); // ORDENA DE FORMA ALFABÉTICA DE A a Z. DE FORMA ASCENDENTE CON NUMEROS. LOS BOOLEANOS CUENTAN COMO STRING

}

