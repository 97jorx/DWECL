window.onmousedown = function(){
    switch(event.button){
        case 0:
            alert("Click izquierdo")
            break;
        case 2:
            alert("Click Derecho")
            break;
        case 1:
            alert("Botón central")
            break;
    };
}



