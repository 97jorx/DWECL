window.oncontextmenu = function () {
    console.log("Boton derecho del raton deshabilitado");
    return false;
}