 
function mostrar(){
    var url = document.getElementById("img").src;
    alert(url);
    return true;
}