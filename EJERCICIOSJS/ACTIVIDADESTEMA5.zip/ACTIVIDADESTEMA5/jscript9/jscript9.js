window.onresize = function() {
    this.alert("Anchura" + screen.width  + "Alto" + screen.width)
};


