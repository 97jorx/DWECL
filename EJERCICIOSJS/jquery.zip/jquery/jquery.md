### JQUERY

- Es una Biblioteca de JAVASCRIPT ligera,
  cuya filosofía es escribir menos para hacer más.

- Caracteristicas de JQUERY:
  - Manipulación HTML / DOM.
  - Manipulación de CSS.
  - Métodos de evento HTML.
  - Efectos y animaciones.
  - AJAX.
  - Utilidades. 
  
- Es un framework muy usado.

#### El evento Ready del Documento

```javascript
 $(function(){
    // Métodos jQuery van aquí..
});
```

#### Selectores de etiqueta

```
$(document).ready (function () {
    $("button").click(function () {
        $("p").hide().;
        });
});
```