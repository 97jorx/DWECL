
// 13. Utiliza los métodos focus() y blur() para cambiar el color de dos cuadros
// de texto cuando posicionamos el foco y cuando lo retiramos

estado = true;

$(function () {
    $(document).tooltip();
});

