
// 15. Crea un documento con dos tag div, dentro de cada uno de los cuales debe
// haber un botón para esconder dichos tag.

$(document).ready(() => {
    $("div > button").click(function () {
        $("div:nth-of-type(1)").hide();
    });
    $("#button2").click(function () {
        $("div:nth-of-type(2)").hide();
   });
});

