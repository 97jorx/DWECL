
// 2.  En  el  mismo  documento  HTMLanterior.  Al  pulsar  el  botón  debe  ocultarse dicho botón.

$(document).ready(function (){
    $("button").click(function () {
         $(this).hide();
    });
});


