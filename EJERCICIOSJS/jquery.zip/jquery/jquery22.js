

$(document).ready(function(){
    $("div:eq(0)").first().click(function(){
      $("div:eq(0)").slideUp()("slow 0.4");
    
    });
    
});

