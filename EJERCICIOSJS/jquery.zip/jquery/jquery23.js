

$(document).ready(function(){
    $("div:eq(0)").click(function(){
      $("div:eq(1)").slideToggle("slow");
    });
});

