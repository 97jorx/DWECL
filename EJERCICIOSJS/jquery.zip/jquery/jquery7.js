
// 7. Crea un documento con un par de enlaces mediante el atributo href y oculta ambos enlaces

$(document).ready(function (){
    $("button").click(function () {
        $("[href]").hide();
    });
});


