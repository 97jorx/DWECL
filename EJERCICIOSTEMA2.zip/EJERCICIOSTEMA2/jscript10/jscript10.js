var frase = prompt("Introduce una frase : "); 

var caracteres = "";
for (i=0;i<=frase.length-1; i++){
	if(Number.isInteger(parseInt(frase.charAt(i)))){
	   continue;
	}
       	  caracteres = frase.charAt(i);	
          alert(caracteres);
   }



