var valores = [true, 5, false, "hola", "adios", 2];
var aux = "";


alert(valores[3] > valores[4] ? "Es mayor: "+valores[3] : "Es mayor: " + valores[4]);

alert("True o False: " + valores[0] || valores[2])

alert("5 * 2 = " + valores[1] * valores[5]);










