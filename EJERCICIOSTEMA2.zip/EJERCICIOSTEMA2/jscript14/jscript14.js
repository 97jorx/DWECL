function comprobar() {
	var password = document.getElementById('password').value;
	if (password == "hola") {
		alert("Contraseña correcta");
	} else {
		alert("Contraseña incorrecta");
	}
}