var pro1 = prompt("Introduce el primer número");
var num= parseInt(pro1);
var tabla = "";

for(i=0;i<=10;i++){
    document.write(tabla = + "  " + i + "  * " + num + "  = " + (i * num) + " <br> ");
}



