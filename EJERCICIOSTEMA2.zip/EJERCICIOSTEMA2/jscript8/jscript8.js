var valor = prompt("Número introducido : "); 
var parse = parseInt(valor);
switch(parse) {
    case 1: alert("UNO");break;
    case 2: alert("DOS");break;
    case 3: alert("TRES");break;
    case 4: alert("CUATRO");break;
    case 5: alert("CINCO");break;
    default: alert("Error : número desconocido");break;
}
