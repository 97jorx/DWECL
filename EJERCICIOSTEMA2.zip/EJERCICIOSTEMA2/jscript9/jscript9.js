var valor = prompt("Número introducido : "); 

switch(valor) {
    case "casa" : alert("house");  break;
    case "mesa" : alert("table");  break;
    case "perro": alert("dog");    break;
    case "gato" : alert("cat");    break;
    default: alert("Error : palabra desconocida");break;
}
