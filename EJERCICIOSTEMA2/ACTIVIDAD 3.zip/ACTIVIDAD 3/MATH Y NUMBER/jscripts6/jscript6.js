//Busca 3 casos de operaciones artiméticas que generen infinite y 3 casos que generen -Infinite.

// CASO 1 INFINITE
document.write("5/0 --> "+5/0+"<br>");
// CASO 2 INFINITE
document.write("Math.log(0) --> "+Math.log(0)*-1+"<br>");
// CASO 3 INFINITE
document.write("Math.pow(10, 1000) --> "+Math.pow(10, 1000)+"<br>");


document.write("<br>");


// CASO 1 -INFINITE
document.write("Math.max   --> "+Math.max()+"<br>");
// CASO 2 -INFINITE
document.write("Math.log(0) -->"+Math.log(0)+"<br>");
// CASO 3 -INFINITE
document.write("-1 / 0      --> "+-1 / 0+"<br>");

