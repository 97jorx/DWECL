document.write((Math.PI).toFixed(4));


